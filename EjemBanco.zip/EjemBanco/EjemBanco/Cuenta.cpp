#include "StdAfx.h"
#include "Cuenta.h" // Declarar el Header de la Clase


Cuenta::Cuenta(void)
{
}


Cuenta::~Cuenta(void)
{
}

void Cuenta::set_Nombre(string nom)
{
}

void Cuenta::set_Cuenta(string cue)
{
}
string Cuenta::get_Nombre()
{
	return nombre;
}
string Cuenta::get_Cuenta()
{
	return cuenta;
}
double Cuenta::get_TipoDeInteres()
{
	return tipoDeInteres;
}
double Cuenta::Estado()
{
	return estado;
}
void Cuenta::set_TipoDeInteres(double tipo)
{
}
void Cuenta::reintegro(double cantidad)
{
}
void Cuenta::ingreso (double cantidad)
{
}