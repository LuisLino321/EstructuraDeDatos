#pragma once
#include <string>

using namespace std;

class Cuenta
{
private:   
	//Atributos
	double tipoDeInteres;
	double saldo;
	string cuenta;
	string nombre;
	double estado;

public:
	Cuenta(void); // Constructor
	virtual ~Cuenta(void); //Destructor
	void set_Nombre(string nom);
	void set_Cuenta(string cue);
	string get_Nombre();
	string get_Cuenta();
	double get_TipoDeInteres();
	double Estado();
	void set_TipoDeInteres(double tipo);
	void reintegro(double cantidad);
	void ingreso (double cantidad);
};

